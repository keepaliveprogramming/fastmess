<?php


use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Route;


# use Illuminate\Support\Facades\Route;

/** @var \Laravel\Lumen\Routing\Router $router */

/*
|--------------------------------------------------------------------------
| Application Routes
|--------------------------------------------------------------------------
|
| Here is where you can register all of the routes for an application.
| It is a breeze. Simply tell Lumen the URIs it should respond to
| and give it the Closure to call when that URI is requested.
|
*/

$router->get('/', function () use ($router) {
    return $router->app->version();
});

$router->get('foo', function () {
    return response('Hello World')->header("Content-type", "application/json");
});


// Pobieranie danych z bazy danych
$router->get('/api/users', function () {
    $users = DB::table('users')->get();
    if (is_array($users) && $users != array()) 
        $users = 'no_users';

    return response()->json(array(
        "ok" => true,
        "messages" => $users
    ));
});

// Pobieranie pojedynczego użytkownika na podstawie ID
$router->get('/api/users/{id}', function (Request $request) use ($router) {
    $user = DB::table('users')->find($id);
    if ($user) {
        return response()->json($user);
    } else {
        return response()->json(['message' => 'User not found'], 404);
    }
});
